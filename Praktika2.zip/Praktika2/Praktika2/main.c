#include <8051.h>
void main()
{
unsigned char i,j; // 8 bit
unsigned char massiv [11]=
	{
		0xC0, // massiv
		0xF9,
		0xA4,
		0xB0,
		0x99,
		0x92,
		0x82,
		0xF8,
		0x80,
		0x90,
		0xFF // off
	};
P1=0;
i=9;
while(i<=9)
	{
		P2=massiv[i];
		if(P10>0)
		{
			i--;
			for(j=0;j<100;j++) // zadershka
			continue;
		}
	}
		P2=massiv[10];
		while(1);
}