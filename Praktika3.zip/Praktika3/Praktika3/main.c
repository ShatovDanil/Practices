#include <8051.h>
void main()
{
unsigned int i;
short str[5] = {160+4,160,160+14,160+9,160+12};
P0 = 0x38;
P2 = 0x1;
P2 = 0x0;
P0 = 0x80;
P2 = 0x1;
P2 = 0x0;
for(i=0;i<5;i++) 
{
P0 = str[i];
P2 = 0x3;
P2 = 0x2;
i++;
}
P0 = 0xC0;
P2 = 0x1;
P2 = 0x0;
for(i=1;i<5;i++)
{
P0 = str[i];
P2 = 0x3;
P2 = 0x2;
i++;
}
while(1);
}
