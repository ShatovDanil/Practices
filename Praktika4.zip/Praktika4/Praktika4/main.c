#include <8051.h> 
unsigned char* init()
{
	unsigned char array[6];
	array[0]=0x0; 
	array[1]=0x1;  //T=1s = 2
	array[2]=0x6;  //T=2s = 4
	array[3]=0x38; //T=3s = 6 
	array[4]=0x40;  //T=1s = 2
	array[5]=0x80;  //T=3,5s = 7
	return array;
} 

void msec (int x)  
{
	while(x-->0) 
	{
		TH0 = (-10000)>> 8;  
		TL0= (-10000); 
		TR0=1; 
		do;
		while(TF0==0);  
		TF0=0; 
		TR0=0;  
	}
}

void main() 
{
	int i;
	unsigned char*array = init();
	TMOD=0x1;
	while(1)
	{
		P1=array[0]; 
		msec(0.5);//0,5 sec
		for(i=1;i<=21;i++) 
		{
			if(i<=2) P1=array[1];
			else if(i<=6 && i >2) P1=array[2];
			else if(i<=12 && i >6) P1=array[3];
			else if(i<=14 && i >12) P1=array[4];
			else P1=array[5];			 
			msec(0.5);//0,5 sec 
		}	
	}
}
